This is an simple online web store was made by using php , mysql and bootstrap. 

 name and pass for log in is admin , admin. Just to make it simple. 

2 main things are not fully implemented is contact and process purchase. 
the process site is just a place holder. 

